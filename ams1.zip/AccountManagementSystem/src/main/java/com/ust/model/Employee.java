package com.ust.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor 
@RequiredArgsConstructor 
@Entity
//@AllArgsConstructor
public class Employee {
	
//	@Id
//	@GeneratedValue
//	private Integer empid;
	
	
	@NonNull
	private String Active;
	
	@NonNull
	private String Alias;
	
	@NonNull
	private String Project;
	
	@NonNull
	private String FGWorkername;
	
	@NonNull
	private String FGID;
	
	
	@Id
	@NonNull
	private Integer USTID;
	
	@NonNull
	private String USTWorkern;
	
	@NonNull
	private Date MSStartDate;
	
	@NonNull
	private Date MSEndDate;
	
	@NonNull
	private String Typeofemployment;
	
	@NonNull
	private String Role;
	
	@NonNull
	private String Deliverytype;
	
	@NonNull
	private String ProjectID;
	
	@NonNull
	private String ProjectStartDate;
	
	@NonNull
	private Double ProjectEndDate;
	
	@NonNull
	private String USTStart;

	@NonNull
	private Double AccountAllocationStart;

	@NonNull
	private String AccountReleaseDate;

	@NonNull
	private String WorkerID;

	@NonNull
	private String WorkOrderID ;

	
	@NonNull
	private String BusinessUnit;

	@NonNull
	private String WorkerNPC;
	@NonNull
	private String WorkerSupervisor;
	@NonNull
	private Double OriginalStartDate;
	@NonNull
	private Double WorkerStartDate;
	@NonNull
	private Double LatestWOED;
	@NonNull
	private String WorkerStatus;
	
	@NonNull
	private String Currency;
	
	@NonNull
	private Double BillRateST;
	
	@NonNull
	private String JobPostingID;
	
	@NonNull
	private String MSLocation;
	
	@NonNull
	private String Country;
	
	@NonNull
	private String City;
	
	@NonNull
	private String SkillCategory;
	
	@NonNull
	private String Skill;
	
	@NonNull
	private Double TotalExp;
	
	@NonNull
	private Double BillRate;
	
	@NonNull
	private Double Cost;
	
	@NonNull
	private Double CostLocal;
	
	@NonNull
	private String GM;
	
	@NonNull
	private String NetEBITDA;
	
	@NonNull
	private String BU;
	@NonNull
	private String Division;
	
	@NonNull
	private String SuperDepartment;
	
	@NonNull
	private String Department;
	
	@NonNull
	private String Comment;
	

}
