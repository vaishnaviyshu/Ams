package com.ust.model;



import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor 
@RequiredArgsConstructor 
@Entity
@AllArgsConstructor
public class So {

	@Id
	@GeneratedValue
	private Integer soid;

	@NonNull
	private String OpenPosition;

	@NonNull
	private String FulfilledPostion;

	@NonNull
	private String Cancelled_Hold;

	@NonNull
	private Date DemandOpenDate;
	
	@NonNull
	private Date DemandClosedDate;
	
	@NonNull
	private String Remarks;
	
	@NonNull
	private String ClientHM;
	
	@NonNull
	private String USTaccountPOC;
	
	@NonNull
	private String USTRecruiter;
	
	@NonNull
	private String CreatedBy;
	
	@NonNull
	private Date CreatedOn;
	
	@NonNull
	private String ModifiedBy;
	
	@NonNull
	private Date ModifiedOn;




}

