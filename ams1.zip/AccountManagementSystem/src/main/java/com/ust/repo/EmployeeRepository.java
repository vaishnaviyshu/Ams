package com.ust.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ust.model.Employee;
import com.ust.model.Product;

public interface EmployeeRepository extends JpaRepository<Employee,Integer>{


}
