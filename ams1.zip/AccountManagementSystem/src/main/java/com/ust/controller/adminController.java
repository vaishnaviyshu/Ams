package com.ust.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.ust.model.Employee;
import com.ust.model.Message;
import com.ust.model.Product;
import com.ust.service.Iemployeeservice;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/admin")
public class adminController {
	
	@Autowired 
	private Iemployeeservice service; 


	@PostMapping("/addemp") 
	public ResponseEntity<Message> saveStudent(@RequestBody Employee student) 
	{ 
		ResponseEntity<Message> resp=null; 
		try {
			Integer id=service.saveStudent(student);  	 	 	
			resp=new ResponseEntity<Message>(new Message("SUCCESS",id+"-saved"),HttpStatus.OK); 
		} catch (Exception e) {  	 	 
			resp=new ResponseEntity<Message>(new Message("FAIL","Unable to Save"),HttpStatus.OK); 
			e.printStackTrace(); 
		} 
		return resp; 
	} 
	
//	@PostMapping("/UploadExcel") 
//	public ResponseEntity<Message> saveStudent1(@RequestBody Employee student) 
//	{ 
//		ResponseEntity<Message> resp=null; 
//		try {
//			Integer id=service.saveStudent1(student);  	 	 	
//			resp=new ResponseEntity<Message>(new Message("SUCCESS",id+"-saved"),HttpStatus.OK); 
//		} catch (Exception e) {  	 	 
//			resp=new ResponseEntity<Message>(new Message("FAIL","Unable to Save"),HttpStatus.OK); 
//			e.printStackTrace(); 
//		} 
//		return resp; 
//	} 
	
	@GetMapping("/viewemp")
	public ResponseEntity<?> getEmployee(){
		ResponseEntity<?> resp=null;
		try {
			List<Employee> l=service.getEmployees();
			if(l!=null && !l.isEmpty()) {
				resp=new ResponseEntity<List<Employee>>(l,HttpStatus.OK);
			}else {
				resp=new ResponseEntity<String>("No data found",HttpStatus.OK);
			}
		}catch (Exception e){
			resp=new ResponseEntity<String>("Unable to fetch data ",HttpStatus.INTERNAL_SERVER_ERROR);
			e.printStackTrace();
		}
		return resp;
	}
	
	
	@GetMapping("/one/{id}")  	
	public ResponseEntity<?> getOneStudent(@PathVariable Integer id) 
	{ 
		ResponseEntity<?> resp=null; 
		try { 
			Optional<Employee> opt=service.getOneEmployees(id); 
			if(opt.isPresent())  
				resp=new 
				ResponseEntity<Employee>(opt.get(),HttpStatus.OK); 
			else 
				resp=new ResponseEntity<String>("No Data Found",HttpStatus.BAD_REQUEST); 
		} catch (Exception e) { 
			resp=new ResponseEntity<String>("Unable to Fetch Data",HttpStatus.INTERNAL_SERVER_ERROR); 
					e.printStackTrace(); 
		} 
		return resp;
	}
	
	@DeleteMapping("/remove/{id}") 
	public ResponseEntity<Message> deleteStudent(@PathVariable Integer id) 
	{ 
		System.out.println("welcome");  	 	
		ResponseEntity<Message> resp=null; 
		try { 
			boolean exist=service.isExist(id); 
			if(exist) {  	 	 	 	
				service.deleteStudent(id);  	 	 	 	
				resp=new ResponseEntity<Message>(new Message("SUCCESSS",id+"-removed"),HttpStatus.OK); 
			}else { 
				resp=new ResponseEntity<Message>(new Message("FAIL",id+"-Not Exist"),HttpStatus.BAD_REQUEST); 
			} 
		} catch (Exception e) { 
			resp=new ResponseEntity<Message>(new Message("FAIL","Unable to Delete"),HttpStatus.INTERNAL_SERVER_ERROR); 
			e.printStackTrace(); 
		} 

		return resp; 
	} 
//	@PutMapping("/update")  	
//	public ResponseEntity<Message> updateStudent(@RequestBody Employee employee) {  
//		ResponseEntity<Message> resp=null; 
//			try { 
//				boolean exist=service.isExist(employee.getEmpid()); 
//				if(exist) { 
//					service.saveStudent(employee); 
//					resp=new ResponseEntity<Message>(new 
//							Message("OK",employee.getEmpid()+"-Updated"),HttpStatus.OK); 
//				}else { 
//					resp=new ResponseEntity<Message>(new 
//							Message("OK",employee.getEmpid()+"-Not Exist"),HttpStatus.BAD_REQUEST); 
//				} 
//			} catch (Exception e) { 
//				resp=new ResponseEntity<Message>(new 
//						Message("OK","Unable to Update"),HttpStatus.INTERNAL_SERVER_ERROR); 
//				e.printStackTrace(); 
//			} 
//			return resp; 
//	} 
	
	
	 
	  @RequestMapping(value = "/UploadExcel", method = RequestMethod.POST)
	    public ResponseEntity<List<Employee>> importExcelFile(@RequestParam("file") MultipartFile files) throws IOException {
	        HttpStatus status = HttpStatus.OK;
	        List<Employee> productList = new ArrayList<>();
	        Employee product = new Employee();

	        XSSFWorkbook workbook = new XSSFWorkbook(files.getInputStream());
	        XSSFSheet worksheet = workbook.getSheetAt(0);

	        for (int index = 0; index < worksheet.getPhysicalNumberOfRows(); index++) {
	            if (index > 0) {
//	                Employee product = new Employee();

	                XSSFRow row = worksheet.getRow(index);
	                
//	                System.out.println(row.getCell(5)+"hellooooooooooooooo");
	                Integer id = (int) row.getCell(5).getNumericCellValue();

	                product.setUSTID(id);    //ust id
	                
	                
	                product.setActive(row.getCell(0).getStringCellValue());
//	                product.(row.getCell(1).getNumericCellValue());
	                product.setAlias(row.getCell(1).getStringCellValue());
	                product.setProject(row.getCell(2).getStringCellValue());
	                product.setFGWorkername(row.getCell(3).getStringCellValue());
	                product.setFGID(row.getCell(4).getStringCellValue());
//	                product.setUSTID(row.getCell(7).getStringCellValue());
	                
	                product.setUSTWorkern(row.getCell(6).getStringCellValue());
	                product.setMSStartDate(row.getCell(7).getDateCellValue());
	                product.setMSEndDate(row.getCell(8).getDateCellValue());
	               
	                product.setTypeofemployment(row.getCell(9).getStringCellValue());
	                product.setRole(row.getCell(10).getStringCellValue());
	                product.setDeliverytype(row.getCell(11).getStringCellValue());
	                
	                product.setProjectID(row.getCell(12).getStringCellValue());
	                product.setProjectStartDate(row.getCell(13).getStringCellValue());
	                
	                product.setProjectEndDate(row.getCell(14).getNumericCellValue());
	                product.setUSTStart(row.getCell(15).getStringCellValue());
	                
	                product.setAccountAllocationStart(row.getCell(16).getNumericCellValue());
	                product.setAccountReleaseDate(row.getCell(17).getStringCellValue());
	                
	                product.setWorkerID(row.getCell(18).getStringCellValue());
	                product.setWorkOrderID(row.getCell(19).getStringCellValue());
	                product.setBusinessUnit(row.getCell(20).getStringCellValue());
	                product.setWorkerNPC(row.getCell(21).getStringCellValue());
	                
	                product.setWorkerSupervisor(row.getCell(22).getStringCellValue());
	                product.setOriginalStartDate(row.getCell(23).getNumericCellValue());
	                product.setWorkerStartDate(row.getCell(24).getNumericCellValue());
	                product.setLatestWOED(row.getCell(25).getNumericCellValue());
	                
	                product.setWorkerStatus(row.getCell(26).getStringCellValue());
	                product.setCurrency(row.getCell(27).getStringCellValue());
	                product.setBillRateST(row.getCell(28).getNumericCellValue());
	                product.setJobPostingID(row.getCell(29).getStringCellValue());
	                product.setMSLocation(row.getCell(30).getStringCellValue());
	                product.setCountry(row.getCell(31).getStringCellValue());
	                product.setCity(row.getCell(32).getStringCellValue());
	                product.setSkillCategory(row.getCell(33).getStringCellValue());
	                product.setSkill(row.getCell(34).getStringCellValue());
	                product.setTotalExp(row.getCell(35).getNumericCellValue());
	                
	                product.setBillRate(row.getCell(36).getNumericCellValue());
	                product.setCost(row.getCell(37).getNumericCellValue());
	                product.setCostLocal(row.getCell(38).getNumericCellValue());
	                product.setGM(row.getCell(39).getStringCellValue());
	                product.setNetEBITDA(row.getCell(40).getCellFormula());
	                product.setBU(row.getCell(41).getStringCellValue());
	                product.setDivision(row.getCell(42).getStringCellValue());
	                product.setSuperDepartment(row.getCell(43).getStringCellValue());
	                product.setDepartment(row.getCell(44).getStringCellValue());
	                product.setComment(row.getCell(45).getStringCellValue());
//	                product.setWorkerStatus(row.getCell(46).getStringCellValue());
//	                product.setWorkerStatus(row.getCell(47).getStringCellValue());
	                
	                
//	                product.setWorkerStatus(row.getCell(26).getStringCellValue());
//	                product.setCategory(row.getCell(3).getStringCellValue());

	                productList.add(product);
	                ResponseEntity<Message> resp=null; 
	        		try {
	        			Integer uid=service.Employeexl(product);  	 	 	
	        			resp=new ResponseEntity<Message>(new Message("SUCCESS",id+"-saved"),HttpStatus.OK); 
	        		} catch (Exception e) {  	 	 
	        			resp=new ResponseEntity<Message>(new Message("FAIL","Unable to Save"),HttpStatus.OK); 
	        			e.printStackTrace(); 
	        		} 
	            }
	        }
	       
//    		return resp; 

//	        return new ResponseEntity<>(productList, status);
	        return new ResponseEntity<>(productList, status);
	    }
	
	
//	  @RequestMapping(value = "/prod", method = RequestMethod.POST)
//	    public ResponseEntity<List<Product>> importExcelFile1(@RequestParam("file") MultipartFile files) throws IOException {
//	        HttpStatus status = HttpStatus.OK;
//	        List<Product> productList = new ArrayList<>();
//	        Product product = new Product();
//
//	        XSSFWorkbook workbook = new XSSFWorkbook(files.getInputStream());
//	        XSSFSheet worksheet = workbook.getSheetAt(0);
//
//	        for (int index = 0; index < worksheet.getPhysicalNumberOfRows(); index++) {
//	            if (index > 0) {
//	                
//
//	                XSSFRow row = worksheet.getRow(index);
//	                Integer id = (int) row.getCell(0).getNumericCellValue();
//
//	                product.setProductid(id);
//	                product.setProductName(row.getCell(1).getStringCellValue());
//	                product.setProductPrice(row.getCell(2).getNumericCellValue());
//	                product.setCategory(row.getCell(3).getStringCellValue());
//
//	                productList.add(product);
//	            }
//	            
//	            
//	        }
//	        ResponseEntity<Message> resp=null; 
//    		try {
//    			Integer id=service.saveStudent1(product);  	 	 	
//    			resp=new ResponseEntity<Message>(new Message("SUCCESS",id+"-saved"),HttpStatus.OK); 
//    		} catch (Exception e) {  	 	 
//    			resp=new ResponseEntity<Message>(new Message("FAIL","Unable to Save"),HttpStatus.OK); 
//    			e.printStackTrace(); 
//    		} 
////    		return resp; 
//
//	        return new ResponseEntity<>(productList, status);
//	    }


}
