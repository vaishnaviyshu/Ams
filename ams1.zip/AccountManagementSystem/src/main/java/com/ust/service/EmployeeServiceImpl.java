package com.ust.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.ust.model.Employee;
import com.ust.model.Product;
//import com.ust.model.Student;
import com.ust.repo.EmployeeRepository;
import com.ust.repo.ProductRepo;


@Service
public class EmployeeServiceImpl implements Iemployeeservice{
	
	@Autowired
	private EmployeeRepository repo;
	@Autowired
	private ProductRepo repop;

	@Override
	public Integer saveStudent(Employee e) {
		// TODO Auto-generated method stub
		return repo.save(e).getUSTID();
	}

	@Override
	public List<Employee> getEmployees() {
		
		return repo.findAll();
	}

	@Override 
 	public Optional<Employee> getOneEmployees(Integer id) { 
 	 	return repo.findById(id); 
 	}

	@Override 
 	public boolean isExist(Integer id) {  	return repo.existsById(id); 
}

	@Override 
 	public void deleteStudent(Integer id) {  	 				
 		repo.deleteById(id); 
 	}

	@Override
	public Integer Employeexl(Employee e) {
		// TODO Auto-generated method stub
		return repo.save(e).getUSTID();
	}

//	@Override
//	public Integer saveStudent1(Employee student) {
//		// TODO Auto-generated method stub
//		return repo.save(student).getEmpid();
//	}

//	@Override
//	public Integer saveStudent1(Product product) {
//		// TODO Auto-generated method stub
//		return repop.save(product).getProductid();
//	}

}
