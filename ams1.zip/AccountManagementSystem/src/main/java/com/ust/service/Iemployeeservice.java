package com.ust.service;

import java.util.List;
import java.util.Optional;

import org.springframework.web.multipart.MultipartFile;

import com.ust.model.Employee;
import com.ust.model.Product;

public interface Iemployeeservice {

	public Integer saveStudent(Employee e);

	public List<Employee> getEmployees();

	public Optional<Employee> getOneEmployees(Integer id);

	public boolean isExist(Integer id);

	public void deleteStudent(Integer id);

	public Integer Employeexl(Employee e);
	

}
