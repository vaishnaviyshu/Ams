package com.ust.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor 
@RequiredArgsConstructor 
@Entity
@AllArgsConstructor
public class Employee {
	
	@Id
	@GeneratedValue
	private Integer empid;
	
	@NonNull
	private String empname;
	
	@NonNull
	private Long empsal;
	
	@NonNull
	private String empemail;
	
	@NonNull
	private Long empphone;
	
	@NonNull
	private String emplocation;
	

}
