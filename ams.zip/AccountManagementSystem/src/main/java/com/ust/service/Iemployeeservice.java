package com.ust.service;

import java.util.List;
import java.util.Optional;

import com.ust.model.Employee;

public interface Iemployeeservice {

	public Integer saveStudent(Employee e);

	public List<Employee> getEmployees();

	public Optional<Employee> getOneEmployees(Integer id);

	public boolean isExist(Integer id);

	public void deleteStudent(Integer id);

}
