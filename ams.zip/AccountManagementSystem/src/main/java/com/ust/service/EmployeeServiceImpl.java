package com.ust.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.model.Employee;
//import com.ust.model.Student;
import com.ust.repo.EmployeeRepository;


@Service
public class EmployeeServiceImpl implements Iemployeeservice{
	
	@Autowired
	private EmployeeRepository repo;

	@Override
	public Integer saveStudent(Employee e) {
		// TODO Auto-generated method stub
		return repo.save(e).getEmpid();
	}

	@Override
	public List<Employee> getEmployees() {
		
		return repo.findAll();
	}

	@Override 
 	public Optional<Employee> getOneEmployees(Integer id) { 
 	 	return repo.findById(id); 
 	}

	@Override 
 	public boolean isExist(Integer id) {  	return repo.existsById(id); 
}

	@Override 
 	public void deleteStudent(Integer id) {  	 				
 		repo.deleteById(id); 
 	} 
}
