import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SomoduleComponent } from './somodule/somodule.component';
import { HomepageComponent } from './homepage/homepage.component';
import { SidebarModule } from '@syncfusion/ej2-angular-navigations';
import { HttpClientModule } from '@angular/common/http'
import { FormsModule } from '@angular/forms';
import { EmployeehomeComponent } from './employeehome/employeehome.component';
import { AddemployeeComponent } from './addemployee/addemployee.component' 

@NgModule({
  declarations: [
    AppComponent,
    SomoduleComponent,
    HomepageComponent,
    EmployeehomeComponent,
    AddemployeeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, 
    SidebarModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
