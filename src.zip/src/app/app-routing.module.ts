import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import { EmployeehomeComponent } from './employeehome/employeehome.component';
import { HomepageComponent } from './homepage/homepage.component';
import { SomoduleComponent } from './somodule/somodule.component';

const routes: Routes = [
  {path: 'somodule1' ,component:SomoduleComponent},
  {path: 'homepage',component:HomepageComponent},
  {path: 'emphome',component:EmployeehomeComponent},
  {path: 'addemployee',component:AddemployeeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
