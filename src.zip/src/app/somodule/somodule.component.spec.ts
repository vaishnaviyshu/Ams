import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SomoduleComponent } from './somodule.component';

describe('SomoduleComponent', () => {
  let component: SomoduleComponent;
  let fixture: ComponentFixture<SomoduleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SomoduleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SomoduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
