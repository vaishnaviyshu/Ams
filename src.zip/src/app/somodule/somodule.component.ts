import { Component, OnInit, ViewChild } from '@angular/core';
import { SidebarComponent } from '@syncfusion/ej2-angular-navigations';


@Component({
  selector: 'app-somodule',
  templateUrl: './somodule.component.html',
  styleUrls: ['./somodule.component.css']
})
export class SomoduleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  @ViewChild('sidebar', { static: false })
  sidebar!: SidebarComponent;


  public showBackdrop: boolean = true;
 
              public closeOnDocumentClick: boolean = true;
 
 
 
              closeClick(): void {
 
                  this.sidebar.hide();
 
              };
 
 
 
              toggleClick():void{
 
                this.sidebar.show();
 
              } 

}
