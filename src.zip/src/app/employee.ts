export class Employee {
        empid!: number;    
        empname!: string;     
        empsal!: string;     
        empemail!: string;
        empphone!: number; 
        emplocation!: string; 
        } 
        