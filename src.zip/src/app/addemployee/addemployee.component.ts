import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { Message } from '../message';

@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent implements OnInit {

  student : Employee = new Employee();   message : Message = new Message(); 
 
  constructor(private service:EmployeeService,private router:Router) { }  
  ngOnInit(): void { 
   } 
  createStudent(){ 
    this.service.createStudent(this.student).subscribe(data=>{       
      this.message=data;
    }); 
    this.student=new Employee(); 
  } 

}
