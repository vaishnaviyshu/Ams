import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { data } from '@syncfusion/ej2';
import { Observable } from 'rxjs';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { Message } from '../message';

@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent implements OnInit {

  @ViewChild('fileInput') fileInput: any;  
  message1!: string;  
  allUsers!: Observable<Employee[]>;

  student : Employee = new Employee();   message : Message = new Message(); 
 
  constructor(private service:EmployeeService,private router:Router) { }  
  ngOnInit(): void { 
   } 
  createStudent(){ 
    this.service.createStudent(this.student).subscribe(data=>{       
      this.message=data;
    }); 
    this.student=new Employee(); 
  
  } 

  uploadFile() {  
    let formData = new FormData();  
    formData.append('file', this.fileInput.nativeElement.files[0])  
  
    this.service.UploadExcel(formData).subscribe(result => {  
      this.message1 = result.toString();  

      console.log(formData,"helo");
      this.router.navigate(['emphome'])  
    });   
  }
}
