import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from './employee';
import { Message } from './message';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private baseUrl : string = 'http://localhost:9898/ams/admin'; 
 
  constructor(private http:HttpClient) { } 
 
  getAllStudents():Observable<Employee[]>{ 
    return this.http.get<Employee[]>(`${this.baseUrl}/viewemp`); 
  }  
  deleteOneStudent(id:number):Observable<Message>{ 
    return this.http.delete<Message>(`${this.baseUrl}/remove/${id}`); 
  }  
  createStudent(student:Employee):Observable<Message>{ 
    return this.http.post<Message>(`${this.baseUrl}/addemp`,student); 
  }  
  getOneStudent(id:number):Observable<Employee>{ 
    return this.http.get<Employee>(`${this.baseUrl}/one/${id}`); 
  }  
  updateStudent(student:Employee):Observable<Message>{ 
   return this.http.put<Message>(`${this.baseUrl}/update`,student); 
  } 


  UploadExcel(formData: FormData) {  
    let headers = new HttpHeaders();  
  
    headers.append('Content-Type', 'multipart/form-data');  
    headers.append('Accept', 'application/json');  
  
    const httpOptions = { headers: headers };  
  
    return this.http.post(this.baseUrl + '/UploadExcel', formData, httpOptions)  
  }  
  BindUser(): Observable<Employee[]> {  
    return this.http.get<Employee[]>(this.baseUrl + '/UserDetails');  
  }  
}
