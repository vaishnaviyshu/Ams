import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { Message } from '../message';

@Component({
  selector: 'app-employeehome',
  templateUrl: './employeehome.component.html',
  styleUrls: ['./employeehome.component.css']
})
export class EmployeehomeComponent implements OnInit {
  employee!: Employee[]; 
  message  : Message = new Message(); 

  constructor(private service:EmployeeService, private router:Router) {
  } 
  
   ngOnInit(): void {     
    this.getAllStudents(); 
   }  
   getAllStudents(){ 
     this.service.getAllStudents().subscribe(data=>{this.employee=data}
 ,       error=>{         this.employee=[] 
       });   } 
   deleteStudent(id:number){ 
     this.service.deleteOneStudent(id).subscribe( 
       data=>{         this.message=data,         this.getAllStudents(); 
       }, 
       error=>{console.log(error)} 
       ); 
        } 
   editStudent(id:number){ 
     this.router.navigate(['edit',id]); 
   } 


   addemployee(){
    this.router.navigate(['addemployee'])
   }
  
 } 
 
