import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employeemoredetails',
  templateUrl: './employeemoredetails.component.html',
  styleUrls: ['./employeemoredetails.component.css']
})
export class EmployeemoredetailsComponent implements OnInit {
  employee!: Employee;   
  id!: number; 
  constructor(private service:EmployeeService,private activeRouter:ActivatedRoute, private router:Router) { } 
 
  ngOnInit(): void {
    this.employee =new Employee(); 
    this.id=this.activeRouter.snapshot.params['id'];     
    this.service.getOneStudent(this.id).subscribe(       data=>{ 
        this.employee=data; 
      } 
      );  
  }

}
