import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeemoredetailsComponent } from './employeemoredetails.component';

describe('EmployeemoredetailsComponent', () => {
  let component: EmployeemoredetailsComponent;
  let fixture: ComponentFixture<EmployeemoredetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployeemoredetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmployeemoredetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
